﻿using MediatR;
using Persistence.Models;
using Persistence.Repositories;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading;
using System.Threading.Tasks;


namespace Core.Features.Commands.CreateTableSpecification
{
    public class CreateTableSpecificationCommand : IRequest<CreateTableSpecificationResponse>
    {
        [Required]
        public Guid TableId { get; set; }
        public int TableNumber { get; set; }
        public int ChairNumber { get; set; }
        [Required]
        public string TablePic { get; set; }
        public string? TableType { get; set; }
    }
}