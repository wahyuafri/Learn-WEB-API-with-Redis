using MediatR;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using Core.Features.Commands.CreateTableSpecification;
using Core.Features.Commands.UpdateTableSpecification;
using Core.Features.Commands.DeleteTableSpecification;
using Core.Features.Queries.GetTableSpecifications;

namespace YourNamespace.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TableController : ControllerBase
    {
        private readonly IMediator _mediator;

        public TableController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        [Route("create")]
        public async Task<IActionResult> CreateTable([FromBody] CreateTableSpecificationCommand command)
        {
            if (command == null)
            {
                return BadRequest("Invalid request");
            }

            var response = await _mediator.Send(command);

            return CreatedAtAction(nameof(GetTableById), new { id = response.TableId }, response);
        }

        [HttpPut]
        [Route("update")]
        public async Task<IActionResult> UpdateTable([FromBody] UpdateTableSpecificationCommand command)
        {
            if (command == null)
            {
                return BadRequest("Invalid request");
            }

            var response = await _mediator.Send(command);

            if (response == null)
            {
                return NotFound($"Table with ID {command.TableId} not found");
            }

            return Ok(response);
        }

        [HttpDelete]
        [Route("delete/{id}")]
        public async Task<IActionResult> DeleteTable(Guid id)
        {
            var command = new DeleteTableSpecificationCommand { TableId = id };
            var success = await _mediator.Send(command);

            if (!success)
            {
                return NotFound($"Table with ID {id} not found");
            }

            return NoContent();
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<GetTableSpecificationsResponse> GetTableById(Guid id)
        {
            var query = new GetTableSpecificationsQuery { TableSpecificationId = id };
            var response = await _mediator.Send(query);

            //if (response == null)
            //{
            //    return NotFound($"Table with ID {id} not found");
            //}

            return response;
        }
    }
}